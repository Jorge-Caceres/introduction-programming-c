#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

/*
    Alumno: Jorge Caceres Flores
    C.I.: 4787628
    Cree una función que halle el maximo comun divisor de 3 numeros enteros. en caso de que no exista es decir que el MCD sea 1 diga que los números son primos entre si.
*/

int getGCD(int n1, int n2, int n3);

int main()
{
    int n1, n2, n3, gcd;

    printf("Maximo comun divisor de tres numeros.\n");
    printf("Ingrese el primer numero: ");
    scanf("%d", &n1);
    getchar();

    printf("Ingrese el segundo numero: ");
    scanf("%d", &n2);
    getchar();

    printf("Ingrese el tercer numero: ");
    scanf("%d", &n3);
    getchar();

    gcd = getGCD(n1, n2, n3);

    if (gcd == 1)
    {
        printf("Los numeros [%d] [%d] [%d] son primos\n", n1, n2, n3);
    }
    else
    {
        printf("MCD de [%d] [%d] [%d] = [%d]\n", n1, n2, n3, gcd);
    }

    return 0;
}

int getGCD(int n1, int n2, int n3){
    int gcd = 0;
    int st =0;
    st = n1 < n2 ? (n1 < n3 ? n1 : n3) : (n2 < n3 ? n2 : n3);
    for (gcd = st; gcd >= 1; gcd--)
    {
        if (n1 % gcd == 0 && n2 % gcd == 0 && n3 % gcd == 0)
            break;
    }
    return gcd;
}
